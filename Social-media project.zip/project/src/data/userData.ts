import { UserData } from '../types';

// Sample dataset of user activity
export const userData: UserData[] = [
  { id: 1, name: "User 1", screenTime: 120, logins: 15, likes: 45, comments: 12, platformUsage: 7, cluster: 1, riskScore: 65, riskLevel: 'Medium' },
  { id: 2, name: "User 2", screenTime: 240, logins: 25, likes: 120, comments: 35, platformUsage: 9, cluster: 2, riskScore: 85, riskLevel: 'High' },
  { id: 3, name: "User 3", screenTime: 60, logins: 5, likes: 10, comments: 3, platformUsage: 3, cluster: 0, riskScore: 25, riskLevel: 'Low' },
  { id: 4, name: "User 4", screenTime: 180, logins: 18, likes: 60, comments: 20, platformUsage: 6, cluster: 1, riskScore: 60, riskLevel: 'Medium' },
  { id: 5, name: "User 5", screenTime: 300, logins: 30, likes: 150, comments: 45, platformUsage: 10, cluster: 2, riskScore: 95, riskLevel: 'High' },
  { id: 6, name: "User 6", screenTime: 90, logins: 8, likes: 25, comments: 7, platformUsage: 4, cluster: 0, riskScore: 35, riskLevel: 'Low' },
  { id: 7, name: "User 7", screenTime: 210, logins: 22, likes: 80, comments: 25, platformUsage: 8, cluster: 2, riskScore: 75, riskLevel: 'High' },
  { id: 8, name: "User 8", screenTime: 150, logins: 12, likes: 40, comments: 15, platformUsage: 5, cluster: 1, riskScore: 55, riskLevel: 'Medium' },
  { id: 9, name: "User 9", screenTime: 270, logins: 28, likes: 130, comments: 40, platformUsage: 9, cluster: 2, riskScore: 90, riskLevel: 'High' },
  { id: 10, name: "User 10", screenTime: 75, logins: 6, likes: 15, comments: 5, platformUsage: 3, cluster: 0, riskScore: 30, riskLevel: 'Low' },
  { id: 11, name: "User 11", screenTime: 195, logins: 20, likes: 70, comments: 22, platformUsage: 7, cluster: 1, riskScore: 70, riskLevel: 'Medium' },
  { id: 12, name: "User 12", screenTime: 45, logins: 4, likes: 8, comments: 2, platformUsage: 2, cluster: 0, riskScore: 20, riskLevel: 'Low' },
  { id: 13, name: "User 13", screenTime: 225, logins: 24, likes: 100, comments: 30, platformUsage: 8, cluster: 2, riskScore: 80, riskLevel: 'High' },
  { id: 14, name: "User 14", screenTime: 135, logins: 14, likes: 50, comments: 18, platformUsage: 6, cluster: 1, riskScore: 60, riskLevel: 'Medium' },
  { id: 15, name: "User 15", screenTime: 285, logins: 29, likes: 140, comments: 42, platformUsage: 10, cluster: 2, riskScore: 92, riskLevel: 'High' },
];

// Generate cluster visualization data
export const generateClusterData = () => {
  return userData.map(user => ({
    id: user.id,
    name: user.name,
    x: user.screenTime / 3, // Normalize for visualization
    y: (user.likes + user.comments) / 5, // Normalize for visualization
    cluster: user.cluster || 0
  }));
};

// Decision tree data for visualization
export const decisionTreeData: TreeNode = {
  name: "Screen Time > 180?",
  children: [
    {
      name: "No",
      children: [
        {
          name: "Logins > 10?",
          children: [
            { name: "No", children: [{ name: "Low Risk", value: 4 }] },
            { name: "Yes", children: [{ name: "Medium Risk", value: 3 }] }
          ]
        }
      ]
    },
    {
      name: "Yes",
      children: [
        {
          name: "Likes > 100?",
          children: [
            { name: "No", children: [{ name: "Medium Risk", value: 5 }] },
            { name: "Yes", children: [{ name: "High Risk", value: 6 }] }
          ]
        }
      ]
    }
  ]
};

// Function to predict risk level for a new user
export const predictRiskLevel = (user: Omit<UserData, 'id' | 'name' | 'cluster' | 'riskScore' | 'riskLevel'>) => {
  let riskScore = 0;
  
  // Simple decision tree implementation
  if (user.screenTime > 180) {
    if (user.likes > 100) {
      riskScore = 85; // High risk
    } else {
      riskScore = 65; // Medium risk
    }
  } else {
    if (user.logins > 10) {
      riskScore = 55; // Medium risk
    } else {
      riskScore = 30; // Low risk
    }
  }
  
  // Determine risk level based on score
  let riskLevel: 'Low' | 'Medium' | 'High';
  if (riskScore < 40) {
    riskLevel = 'Low';
  } else if (riskScore < 70) {
    riskLevel = 'Medium';
  } else {
    riskLevel = 'High';
  }
  
  return {
    riskScore,
    riskLevel,
    cluster: riskLevel === 'Low' ? 0 : riskLevel === 'Medium' ? 1 : 2
  };
};