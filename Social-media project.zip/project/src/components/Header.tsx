import React from 'react';
import { Activity } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="bg-gradient-to-r from-blue-900 to-gray-950 text-white p-4 shadow-md">
      <div className="container mx-auto flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Activity size={28} className="text-blue-400" />
          <h1 className="text-2xl font-bold">Social Media Addiction Detector</h1>
        </div>
        <nav>
          <ul className="flex space-x-6">
            <li className="hover:text-blue-400 transition-colors">Dashboard</li>
            <li className="hover:text-blue-400 transition-colors">Analysis</li>
            <li className="hover:text-blue-400 transition-colors">Predictions</li>
          </ul>
        </nav>
      </div>
      <div className="container mx-auto mt-2 text-sm text-gray-200">
        <p>Developed by Yogapraveen Ravikumar | ML&DL Developer and Full-Stack Developer</p>
      </div>
    </header>
  );
};

export default Header;