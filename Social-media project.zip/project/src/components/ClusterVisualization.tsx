import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';
import { ClusterData } from '../types';

interface ClusterVisualizationProps {
  data: ClusterData[];
}

const ClusterVisualization: React.FC<ClusterVisualizationProps> = ({ data }) => {
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (!svgRef.current || !data.length) return;

    d3.select(svgRef.current).selectAll('*').remove();

    const width = 600;
    const height = 400;
    const margin = { top: 20, right: 20, bottom: 40, left: 40 };
    const innerWidth = width - margin.left - margin.right;
    const innerHeight = height - margin.top - margin.bottom;

    const svg = d3.select(svgRef.current)
      .attr('width', width)
      .attr('height', height)
      .append('g')
      .attr('transform', `translate(${margin.left},${margin.top})`);

    const xScale = d3.scaleLinear()
      .domain([0, d3.max(data, d => d.x) || 100])
      .range([0, innerWidth]);

    const yScale = d3.scaleLinear()
      .domain([0, d3.max(data, d => d.y) || 50])
      .range([innerHeight, 0]);

    const colorScale = d3.scaleOrdinal<number, string>()
      .domain([0, 1, 2])
      .range(['#4CAF50', '#FFC107', '#F44336']);

    svg.append('g')
      .attr('transform', `translate(0,${innerHeight})`)
      .call(d3.axisBottom(xScale))
      .append('text')
      .attr('x', innerWidth / 2)
      .attr('y', 35)
      .attr('fill', 'white')
      .attr('text-anchor', 'middle')
      .text('Screen Time (normalized)');

    svg.append('g')
      .call(d3.axisLeft(yScale))
      .append('text')
      .attr('transform', 'rotate(-90)')
      .attr('y', -35)
      .attr('x', -innerHeight / 2)
      .attr('fill', 'white')
      .attr('text-anchor', 'middle')
      .text('Social Interactions (normalized)');

    svg.selectAll('circle')
      .data(data)
      .enter()
      .append('circle')
      .attr('cx', d => xScale(d.x))
      .attr('cy', d => yScale(d.y))
      .attr('r', 6)
      .attr('fill', d => colorScale(d.cluster))
      .attr('stroke', 'white')
      .attr('stroke-width', 1.5)
      .append('title')
      .text(d => `${d.name}: (${d.x}, ${d.y})`);

    const legend = svg.append('g')
      .attr('transform', `translate(${innerWidth - 100}, 0)`);

    const clusterNames = ['Low Risk', 'Medium Risk', 'High Risk'];
    
    [0, 1, 2].forEach((cluster, i) => {
      const legendRow = legend.append('g')
        .attr('transform', `translate(0, ${i * 20})`);
        
      legendRow.append('rect')
        .attr('width', 10)
        .attr('height', 10)
        .attr('fill', colorScale(cluster));
        
      legendRow.append('text')
        .attr('x', 15)
        .attr('y', 10)
        .attr('text-anchor', 'start')
        .style('font-size', '12px')
        .attr('fill', 'white')
        .text(clusterNames[cluster]);
    });

  }, [data]);

  return (
    <div className="bg-gray-800 rounded-lg shadow p-4">
      <h3 className="text-lg font-semibold mb-4 text-white">K-Means Clustering Visualization</h3>
      <div className="flex justify-center">
        <svg ref={svgRef}></svg>
      </div>
    </div>
  );
};

export default ClusterVisualization;