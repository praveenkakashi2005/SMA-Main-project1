import React, { useState } from 'react';
import { predictRiskLevel } from '../data/userData';
import { AlertTriangle, CheckCircle, AlertCircle } from 'lucide-react';

const PredictionForm: React.FC = () => {
  const [formData, setFormData] = useState({
    screenTime: 120,
    logins: 10,
    likes: 30,
    comments: 15,
    platformUsage: 5
  });
  
  const [prediction, setPrediction] = useState<{
    riskScore: number;
    riskLevel: 'Low' | 'Medium' | 'High';
    cluster: number;
  } | null>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: parseInt(value, 10)
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const result = predictRiskLevel(formData);
    setPrediction(result);
  };

  const renderAlert = () => {
    if (!prediction) return null;
    
    const { riskLevel, riskScore } = prediction;
    
    if (riskLevel === 'Low') {
      return (
        <div className="mt-4 bg-green-900/50 border-l-4 border-green-500 p-4 rounded">
          <div className="flex items-center">
            <CheckCircle className="text-green-500 mr-2" />
            <p className="font-medium text-green-300">
              Low Risk: {riskScore}%
            </p>
          </div>
          <p className="mt-2 text-green-300">
            Your social media usage appears to be healthy. Keep maintaining a balanced digital lifestyle!
          </p>
        </div>
      );
    } else if (riskLevel === 'Medium') {
      return (
        <div className="mt-4 bg-yellow-900/50 border-l-4 border-yellow-500 p-4 rounded">
          <div className="flex items-center">
            <AlertCircle className="text-yellow-500 mr-2" />
            <p className="font-medium text-yellow-300">
              Medium Risk: {riskScore}%
            </p>
          </div>
          <p className="mt-2 text-yellow-300">
            Your social media usage is showing some signs of potential addiction. Consider setting usage limits.
          </p>
        </div>
      );
    } else {
      return (
        <div className="mt-4 bg-red-900/50 border-l-4 border-red-500 p-4 rounded">
          <div className="flex items-center">
            <AlertTriangle className="text-red-500 mr-2" />
            <p className="font-medium text-red-300">
              High Risk: {riskScore}%
            </p>
          </div>
          <p className="mt-2 text-red-300">
            Your social media usage indicates a high risk of addiction. We recommend taking a digital detox and consulting with a professional.
          </p>
        </div>
      );
    }
  };

  return (
    <div className="bg-gray-800 rounded-lg shadow p-6 mt-6">
      <h3 className="text-xl font-semibold mb-4 text-white">Predict Your Addiction Risk</h3>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">
              Daily Screen Time (minutes): {formData.screenTime}
            </label>
            <input
              type="range"
              name="screenTime"
              min="0"
              max="360"
              value={formData.screenTime}
              onChange={handleChange}
              className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">
              Daily Logins: {formData.logins}
            </label>
            <input
              type="range"
              name="logins"
              min="0"
              max="50"
              value={formData.logins}
              onChange={handleChange}
              className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">
              Daily Likes: {formData.likes}
            </label>
            <input
              type="range"
              name="likes"
              min="0"
              max="200"
              value={formData.likes}
              onChange={handleChange}
              className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">
              Daily Comments: {formData.comments}
            </label>
            <input
              type="range"
              name="comments"
              min="0"
              max="100"
              value={formData.comments}
              onChange={handleChange}
              className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">
              Platform Usage Frequency (1-10): {formData.platformUsage}
            </label>
            <input
              type="range"
              name="platformUsage"
              min="1"
              max="10"
              value={formData.platformUsage}
              onChange={handleChange}
              className="w-full h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
            />
          </div>
        </div>
        
        <div className="flex justify-center mt-6">
          <button
            type="submit"
            className="px-6 py-2 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 focus:ring-offset-gray-800"
          >
            Analyze My Risk
          </button>
        </div>
      </form>
      
      {renderAlert()}
    </div>
  );
};

export default PredictionForm;