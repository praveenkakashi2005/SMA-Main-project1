import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';
import { TreeNode } from '../types';

interface DecisionTreeVisualizationProps {
  data: TreeNode;
}

const DecisionTreeVisualization: React.FC<DecisionTreeVisualizationProps> = ({ data }) => {
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (!svgRef.current || !data) return;

    d3.select(svgRef.current).selectAll('*').remove();

    const width = 800;
    const height = 500;
    const margin = { top: 20, right: 120, bottom: 20, left: 120 };
    const innerWidth = width - margin.left - margin.right;
    const innerHeight = height - margin.top - margin.bottom;

    const svg = d3.select(svgRef.current)
      .attr('width', width)
      .attr('height', height)
      .append('g')
      .attr('transform', `translate(${margin.left},${margin.top})`);

    const root = d3.hierarchy(data);
    
    const treeLayout = d3.tree<TreeNode>()
      .size([innerHeight, innerWidth]);
    
    treeLayout(root);

    svg.selectAll('.link')
      .data(root.links())
      .enter()
      .append('path')
      .attr('class', 'link')
      .attr('fill', 'none')
      .attr('stroke', '#4B5563')
      .attr('stroke-width', 2)
      .attr('d', d3.linkHorizontal<d3.HierarchyPointLink<TreeNode>, d3.HierarchyPointNode<TreeNode>>()
        .x(d => d.y)
        .y(d => d.x)
      );

    const nodes = svg.selectAll('.node')
      .data(root.descendants())
      .enter()
      .append('g')
      .attr('class', 'node')
      .attr('transform', d => `translate(${d.y},${d.x})`);

    nodes.append('circle')
      .attr('r', 8)
      .attr('fill', d => {
        if (d.data.name.includes('Low Risk')) return '#4CAF50';
        if (d.data.name.includes('Medium Risk')) return '#FFC107';
        if (d.data.name.includes('High Risk')) return '#F44336';
        return '#60A5FA';
      });

    nodes.append('text')
      .attr('dy', '.31em')
      .attr('x', d => d.children ? -12 : 12)
      .attr('text-anchor', d => d.children ? 'end' : 'start')
      .text(d => d.data.name)
      .style('font-size', '12px')
      .style('font-family', 'Arial')
      .style('fill', 'white');

  }, [data]);

  return (
    <div className="bg-gray-800 rounded-lg shadow p-4 mt-6">
      <h3 className="text-lg font-semibold mb-4 text-white">Decision Tree Classifier</h3>
      <div className="flex justify-center overflow-x-auto">
        <svg ref={svgRef}></svg>
      </div>
    </div>
  );
};

export default DecisionTreeVisualization;