import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts';
import { UserData } from '../types';
import { AlertTriangle, TrendingUp, Users, Clock } from 'lucide-react';

interface DashboardProps {
  userData: UserData[];
}

const Dashboard: React.FC<DashboardProps> = ({ userData }) => {
  const avgScreenTime = Math.round(userData.reduce((sum, user) => sum + user.screenTime, 0) / userData.length);
  const avgLogins = Math.round(userData.reduce((sum, user) => sum + user.logins, 0) / userData.length);
  const avgLikes = Math.round(userData.reduce((sum, user) => sum + user.likes, 0) / userData.length);
  const avgComments = Math.round(userData.reduce((sum, user) => sum + user.comments, 0) / userData.length);

  const riskCounts = userData.reduce((counts, user) => {
    if (user.riskLevel) {
      counts[user.riskLevel] = (counts[user.riskLevel] || 0) + 1;
    }
    return counts;
  }, {} as Record<string, number>);

  const riskData = [
    { name: 'Low', value: riskCounts['Low'] || 0 },
    { name: 'Medium', value: riskCounts['Medium'] || 0 },
    { name: 'High', value: riskCounts['High'] || 0 }
  ];

  const COLORS = ['#4CAF50', '#FFC107', '#F44336'];

  const highRiskUsers = userData.filter(user => user.riskLevel === 'High');

  // Generate trend data
  const trendData = userData.slice(0, 7).map(user => ({
    name: user.name,
    riskScore: user.riskScore || 0,
    screenTime: user.screenTime,
    engagement: (user.likes + user.comments) / 2
  }));

  return (
    <div className="p-6 bg-gray-800 rounded-lg">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold text-white">User Activity Dashboard</h2>
        <div className="text-sm text-gray-400">
          Updated in real-time
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <div className="bg-gray-900 rounded-lg shadow p-4 text-white">
          <div className="flex items-center justify-between">
            <Clock className="text-blue-400" size={24} />
            <span className="text-xs text-gray-400">Daily Average</span>
          </div>
          <h3 className="text-gray-400 text-sm mt-2">Screen Time</h3>
          <p className="text-2xl font-bold">{avgScreenTime} min</p>
          <div className="text-xs text-gray-400 mt-2">
            {avgScreenTime > 180 ? '⚠️ Above recommended' : '✓ Within limits'}
          </div>
        </div>

        <div className="bg-gray-900 rounded-lg shadow p-4 text-white">
          <div className="flex items-center justify-between">
            <Users className="text-green-400" size={24} />
            <span className="text-xs text-gray-400">Daily Average</span>
          </div>
          <h3 className="text-gray-400 text-sm mt-2">Daily Logins</h3>
          <p className="text-2xl font-bold">{avgLogins}</p>
          <div className="text-xs text-gray-400 mt-2">
            {avgLogins > 15 ? '⚠️ High frequency' : '✓ Normal usage'}
          </div>
        </div>

        <div className="bg-gray-900 rounded-lg shadow p-4 text-white">
          <div className="flex items-center justify-between">
            <TrendingUp className="text-purple-400" size={24} />
            <span className="text-xs text-gray-400">Daily Average</span>
          </div>
          <h3 className="text-gray-400 text-sm mt-2">Engagement</h3>
          <p className="text-2xl font-bold">{avgLikes + avgComments}</p>
          <div className="text-xs text-gray-400 mt-2">
            Combined likes and comments
          </div>
        </div>

        <div className="bg-gray-900 rounded-lg shadow p-4 text-white">
          <div className="flex items-center justify-between">
            <AlertTriangle className="text-red-400" size={24} />
            <span className="text-xs text-gray-400">Risk Status</span>
          </div>
          <h3 className="text-gray-400 text-sm mt-2">High Risk Users</h3>
          <p className="text-2xl font-bold">{highRiskUsers.length}</p>
          <div className="text-xs text-gray-400 mt-2">
            Requiring attention
          </div>
        </div>
      </div>

      {highRiskUsers.length > 0 && (
        <div className="mb-8">
          <h3 className="text-xl font-semibold mb-4 text-white">High Risk Alerts</h3>
          <div className="bg-red-900/50 border-l-4 border-red-500 p-4 rounded">
            <div className="flex items-center">
              <AlertTriangle className="text-red-500 mr-2" />
              <p className="font-medium text-red-300">
                {highRiskUsers.length} users showing high addiction risk
              </p>
            </div>
            <div className="mt-2">
              <ul className="list-disc pl-5">
                {highRiskUsers.slice(0, 3).map(user => (
                  <li key={user.id} className="text-red-300">
                    {user.name} - {user.riskScore}% risk score (Screen time: {user.screenTime} min)
                  </li>
                ))}
                {highRiskUsers.length > 3 && (
                  <li className="text-red-300">
                    +{highRiskUsers.length - 3} more users at high risk
                  </li>
                )}
              </ul>
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <div className="bg-gray-900 rounded-lg shadow p-4 text-white">
          <h3 className="text-lg font-semibold mb-4">Risk Score Trends</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={trendData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="name" stroke="#9CA3AF" />
              <YAxis stroke="#9CA3AF" />
              <Tooltip contentStyle={{ backgroundColor: '#1F2937' }} />
              <Legend />
              <Line type="monotone" dataKey="riskScore" name="Risk Score" stroke="#F87171" />
              <Line type="monotone" dataKey="engagement" name="Engagement" stroke="#60A5FA" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-gray-900 rounded-lg shadow p-4 text-white">
          <h3 className="text-lg font-semibold mb-4">Risk Level Distribution</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={riskData}
                cx="50%"
                cy="50%"
                labelLine={true}
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                outerRadius={100}
                fill="#8884d8"
                dataKey="value"
              >
                {riskData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip contentStyle={{ backgroundColor: '#1F2937' }} />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-gray-900 rounded-lg shadow p-4 text-white">
        <h3 className="text-lg font-semibold mb-4">User Activity Details</h3>
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead>
              <tr className="border-b border-gray-700">
                <th className="px-4 py-2 text-left">User</th>
                <th className="px-4 py-2 text-left">Screen Time</th>
                <th className="px-4 py-2 text-left">Logins</th>
                <th className="px-4 py-2 text-left">Engagement</th>
                <th className="px-4 py-2 text-left">Risk Score</th>
                <th className="px-4 py-2 text-left">Status</th>
              </tr>
            </thead>
            <tbody>
              {userData.slice(0, 5).map(user => (
                <tr key={user.id} className="border-b border-gray-700">
                  <td className="px-4 py-2">{user.name}</td>
                  <td className="px-4 py-2">{user.screenTime} min</td>
                  <td className="px-4 py-2">{user.logins}</td>
                  <td className="px-4 py-2">{user.likes + user.comments}</td>
                  <td className="px-4 py-2">{user.riskScore}%</td>
                  <td className="px-4 py-2">
                    <span className={`px-2 py-1 rounded text-xs ${
                      user.riskLevel === 'High' ? 'bg-red-900 text-red-300' :
                      user.riskLevel === 'Medium' ? 'bg-yellow-900 text-yellow-300' :
                      'bg-green-900 text-green-300'
                    }`}>
                      {user.riskLevel}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;