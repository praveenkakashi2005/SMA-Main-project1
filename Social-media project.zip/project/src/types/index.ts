export interface UserData {
  id: number;
  name: string;
  screenTime: number; // in minutes
  logins: number;
  likes: number;
  comments: number;
  platformUsage: number; // frequency score (1-10)
  cluster?: number; // 0: Low, 1: Medium, 2: High
  riskScore?: number; // 0-100
  riskLevel?: 'Low' | 'Medium' | 'High';
}

export interface ClusterData {
  id: number;
  name: string;
  x: number;
  y: number;
  cluster: number;
}

export interface TreeNode {
  name: string;
  children?: TreeNode[];
  value?: number;
}