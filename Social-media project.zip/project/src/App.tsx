import React from 'react';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import ClusterVisualization from './components/ClusterVisualization';
import DecisionTreeVisualization from './components/DecisionTreeVisualization';
import PredictionForm from './components/PredictionForm';
import { userData, generateClusterData, decisionTreeData } from './data/userData';

function App() {
  const clusterData = generateClusterData();

  return (
    <div className="min-h-screen bg-gray-900">
      <Header />
      <main className="container mx-auto py-6 px-4">
        <Dashboard userData={userData} />
        
        <div className="mt-8">
          <h2 className="text-2xl font-bold mb-6 text-white">Machine Learning Analysis</h2>
          <ClusterVisualization data={clusterData} />
          <DecisionTreeVisualization data={decisionTreeData} />
        </div>
        
        <div className="mt-8">
          <h2 className="text-2xl font-bold mb-6 text-white">Risk Prediction</h2>
          <PredictionForm />
        </div>
      </main>
      
      <footer className="bg-gray-950 text-white p-6 mt-12">
        <div className="container mx-auto">
          <p className="text-center">
            © 2025 Social Media Addiction Detector | Developed by Yogapraveen Ravikumar | Powered by Machine Learning
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;